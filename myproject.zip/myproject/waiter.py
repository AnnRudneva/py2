class Waiter:
    def __init__(self,id,fio,telephone,email):
        self.id = id
        self.fio = fio
        self.telephone = telephone
        self.email = email

    def __str__(self):
        return f"{self.id} ФИО:{self.fio} Номер телефона:{self.telephone} Почта:{self.email}"