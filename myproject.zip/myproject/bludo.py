class Bludo:
    def __init__(self,id,name,price,ves):
        self.id = id
        self.name = name
        self.price = price
        self.ves = ves

    def __str__(self):
        return f"{self.id} Название:{self.name} Ценв:{self.price} Вес:{self.ves}"