from client import Client
from bludo import Bludo
from zakaz import Zakaz
from waiter import Waiter

with open("clients.txt",'r',encoding='utf-8') as client_file:
    for line in client_file:
        id,stol,name,age = line.split(";")
        client =Client(id,stol,name,age)
        print(str(client))


