class Zakaz:
    def __init__(self,id,client_id,waiter_id):
        self.bludos =[]
        self.id = id
        self.client = client_id
        self.waiter = waiter_id
    def add_bludo(self,bludo):
        self.bludos.append(bludo)

    def __str__(self):
        return f"{self.id} клиент:{self.client} официант:{self.waiter} блюда:{self.bludos}"