class Client:
    def __init__(self,id,stol,name,age):
       self.id = id
       self.stol = stol
       self.name = name
       self.age = age

    def __str__(self):
        return f"{self.id} стол:{self.stol} имя:{self.name} возраст:{self.age}"